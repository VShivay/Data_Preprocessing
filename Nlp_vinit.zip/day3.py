from textblob import TextBlob

def analyze_sentiment_TextBlob(text):
    sentiment = TextBlob(text).sentiment.polarity
    
    if sentiment > 0:
        return "positive 😊"
    elif sentiment < 0:
        return "negative 😞"
    else:
        return "neutral 😐"
    
A = input("Enter Your Mood : ")
print(f"TextBlob Sentiment: {analyze_sentiment_TextBlob(A)}")

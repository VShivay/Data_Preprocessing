from transformers import pipeline
from flair.models import TextClassifier
from flair.data import Sentence

# HuggingFace Transformers
def analyze_sentiment_transformers(text):
    sentiment_task = pipeline("sentiment-analysis")
    result = sentiment_task(text)[0]
    label = result['label']
    if label == 'POSITIVE':
        return 'positive 😊'
    elif label == 'NEGATIVE':
        return 'negative 😞'
    else:
        return 'neutral 😐'

# Flair
def analyze_sentiment_flair(text):
    classifier = TextClassifier.load('en-sentiment')
    sentence = Sentence(text)
    classifier.predict(sentence)
    sentiment = sentence.labels[0]
    if sentiment.value == 'POSITIVE':
        return 'positive 😊'
    elif sentiment.value == 'NEGATIVE':
        return 'negative 😞'
    else:
        return 'neutral 😐'

# Input prompt
def analyze_input():
    text = input("Enter a sentence for sentiment analysis: ")
    print(f"Transformers Sentiment: {analyze_sentiment_transformers(text)}")
    print(f"Flair Sentiment: {analyze_sentiment_flair(text)}")

analyze_input()
